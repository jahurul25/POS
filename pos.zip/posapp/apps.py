from django.apps import AppConfig


class PosappConfig(AppConfig):
    name = 'posapp'
